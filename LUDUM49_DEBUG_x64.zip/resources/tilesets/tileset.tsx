<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="tileset" tilewidth="64" tileheight="64" tilecount="1" columns="0" objectalignment="center">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="1" type="PlayerStart">
  <properties>
   <property name="BITMAP_NAME" value="player"/>
   <property name="PARTICLE_CREATION" type="bool" value="false"/>
  </properties>
  <image width="64" height="64" source="../sprites/player.png"/>
 </tile>
</tileset>
