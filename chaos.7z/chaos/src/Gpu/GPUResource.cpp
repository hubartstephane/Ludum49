#include <chaos/Chaos.h>

namespace chaos
{

	GPUResource::~GPUResource()
	{
	}

	void GPUResource::Release()
	{
	}

}; // namespace chaos
