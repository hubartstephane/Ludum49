#include <chaos/Chaos.h>

namespace chaos
{
	namespace StreamTools
	{



	} // namespace StringTools

}; // namespace chaos
