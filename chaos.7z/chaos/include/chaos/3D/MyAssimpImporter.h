namespace chaos
{
#ifdef CHAOS_FORWARD_DECLARATION

	class MyAssimpImporter;

#elif !defined CHAOS_TEMPLATE_IMPLEMENTATION

	/**
	* MyAssimpImporter : a base class to import ASSIMP file
	*/

	class MyAssimpImporter
	{
	public:

	};
	
#endif

}; // namespace chaos